Optimised metrics for FreeFem++.

Instructions of use : 

-Install FreeFem++ from 
http://www.freefem.org/ff++/

-Make sure that the compiler ff-c++ is installed
This should be automatic when you installed FreeFem++, 
otherwise see Appendix C in
www.freefem.org/ff++/ftp/freefem++doc.pdf

-In directory metriques, type
ff-c++ AllMetricsToFF.cpp

-Run file Example.edp or MakePictures.edp with FreeFem++.

Notes : The folder include contains the standard include files for compiling with FreeFem++.